package com.horizonmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HorizonMenuClient implements ClientModInitializer {
    public static final String ID = "horizonmenu";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    @Override
    public void onInitializeClient() {
        Config.load();
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen != null && screen.getClass() == TitleScreen.class && Config.get().enabled) {
                client.execute(() -> {
                    Screen cur = Nav.current();
                    if (cur == null || cur == screen) {
                        Nav.open(new HorizonTitleScreen());
                    }
                });
            }
        });
        LOGGER.info("HorizonMenu loaded");
    }
}
